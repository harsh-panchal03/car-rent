## 04-02

DROP TABLE IF EXISTS `city_master`;
CREATE TABLE IF NOT EXISTS `city_master` (
`i_id` int NOT NULL AUTO_INCREMENT,
`i_state_id` int NOT NULL,
`v_city_name` varchar(50) NOT NULL,
`t_is_active` tinyint NOT NULL DEFAULT '1',
`t_is_deleted` tinyint NOT NULL DEFAULT '0',
`dt_created_at` datetime NOT NULL,
`i_created_id` int NOT NULL,
`dt_updated_at` datetime DEFAULT NULL,
`i_updated_id` int DEFAULT NULL,
`dt_deleted_at` datetime DEFAULT NULL,
`i_deleted_id` int DEFAULT NULL,
`v_ip` varchar(20) NOT NULL,
PRIMARY KEY (`i_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;


DROP TABLE IF EXISTS `product_master`;
CREATE TABLE IF NOT EXISTS `product_master` (
`id` INT NOT NULL AUTO_INCREMENT,
`v_name` VARCHAR(255) NOT NULL,
`v_vehicle_type` VARCHAR(100) NOT NULL,
`v_brand` VARCHAR(100) NOT NULL,
`v_model` VARCHAR(100) NOT NULL,
`v_year` VARCHAR(4) NOT NULL,
`v_mileage` VARCHAR(50),
`v_fuel_type` VARCHAR(50),
`v_transmission` VARCHAR(50),
`v_seating_capacity` VARCHAR(10),
`v_rental_price` DECIMAL(10, 2),
`e_availability` ENUM('available', 'unavailable') NOT NULL DEFAULT 'available',
`v_description` TEXT,
`v_image_path` VARCHAR(255),
`t_is_active` TINYINT NOT NULL DEFAULT '1',
`t_is_deleted` TINYINT NOT NULL DEFAULT '0',
`dt_created_at` DATETIME NOT NULL,
`i_created_id` INT NOT NULL,
`dt_updated_at` DATETIME DEFAULT NULL,
`i_updated_id` INT DEFAULT NULL,
`dt_deleted_at` DATETIME DEFAULT NULL,
`i_deleted_id` INT DEFAULT NULL,
`v_ip` VARCHAR(20) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;



DROP TABLE IF EXISTS `order_master`;
CREATE TABLE IF NOT EXISTS `order_master` (
`id` INT NOT NULL AUTO_INCREMENT,

v_name VARCHAR(255), -- Name of the customer
v_phone VARCHAR(255), -- Customer's phone number
v_email VARCHAR(255), -- Customer's email address
v_rental_duration VARCHAR(10), -- Duration of the rental in days (or units)
v_drivers_license VARCHAR(255), -- Driver's license number
v_special_request TEXT, -- Special requests by the customer

i_product_id INT ,

`t_is_active` TINYINT NOT NULL DEFAULT '1',
`t_is_deleted` TINYINT NOT NULL DEFAULT '0',
`dt_created_at` DATETIME NOT NULL,
`i_created_id` INT NOT NULL,
`dt_updated_at` DATETIME DEFAULT NULL,
`i_updated_id` INT DEFAULT NULL,
`dt_deleted_at` DATETIME DEFAULT NULL,
`i_deleted_id` INT DEFAULT NULL,
`v_ip` VARCHAR(20) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;