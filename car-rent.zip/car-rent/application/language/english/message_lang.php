<?php

$lang['anad-electrical'] = "Anand Electrical";
$lang['login-account'] = "Login To Your Account";
$lang['login'] = "Login";
$lang['admin-panel'] = "Admin Panel";
$lang['change-password'] = "Change Password";
$lang['forgot-password'] = "Forgot Password";
$lang['logout'] = "Logout";
$lang['dashboard'] = "Dashboard";
$lang['manage-locations'] = "Manage Locations";
$lang['city'] = "City";
$lang['locality'] = "Locality";
$lang['sub-stations'] = "Sub Stations";
$lang['required-text-input'] = "Please Enter %s ";
$lang['email'] = "Email";
$lang['password'] = "Password";
$lang['inactive-account'] = "This Account Is Inactive Please Contect Your Admin";
$lang['system-error'] = "System Error";
$lang['email-not-exist'] = "Email Or Password Wrong";
$lang['anand-electrical-co'] = "Anand Electrical Co.";
$lang['admin'] = "Admin";
$lang['manage-sub-station'] = "Manage Sub Station";
$lang['sub-stations'] = "Sub Stations";
$lang['no-record-found'] = "No Record Found";
$lang['engineer'] =  "Engineer";
$lang['sub-station-kv'] = "Sub Station KV";
$lang['add-sub-station'] = "Add Sub Station";
$lang['filter'] = "Filter";
$lang['66-kv-sub-station'] = "66 KV Sub Station";
$lang['132-kv-sub-station'] = "132 KV Sub Station";
$lang['220-kv-sub-station'] = "220 KV Sub Station";
$lang['400-kv-sub-station'] = "400 KV Sub Station";
$lang['select'] = "Select";
$lang['sub-station-engineer'] = "Sub Station Engineer";
$lang['all-sub-station'] = "All Sub Station";
$lang['pin-code'] = "Pin Code";
$lang['additional-sub-station-details'] = "Additional Sub Station Details";
$lang['submit'] = "Submit";
$lang['cancel'] = "Cancel";
$lang['common-select-filed-validation'] = "Please Select %s";
$lang['pin-code'] = "Pin Code";

$lang['success-create'] = "Successfully Created %s ";
$lang['error-create'] = "Error Occured While creat %s";

$lang['success-update'] = "Successfully Updated %s ";
$lang['error-update'] = "Error Occured While Update %s";


$lang['success-delete'] = "Successfully Deleted %s ";
$lang['error-delete'] = "Error Occured While Delete %s";

$lang['system-error'] = "System Error";

$lang['sub-station'] = "Sub Station";
$lang['status'] = "Status";
$lang['actions'] = "Actions";
$lang['inactive'] = "Inactive";
$lang['active'] = "Active";
$lang['success-update-status'] = "%s %s SuccessFully";
$lang['error-upadate-status'] = "Error Occured While %s %s";
$lang['update-sub-station'] = "Update Sub Station";

$lang['city'] = "City";
$lang['add-city'] = "Add City";
$lang['update-city'] = "Update City";
$lang['state'] = "State";
$lang['locality'] = "Locality";
$lang['manage-location'] = "Manage Locations";
$lang['add-locality'] = "Add Locality";
$lang['update-locality'] = "Update Locality";

$lang['gujarat'] = "Gujarat";
$lang['maharastra'] = "Maharastra";
$lang['city-name'] = "City Name";
$lang['all-city'] = "All City";
$lang['all-locality'] = "All Locality";
$lang['locality-name'] = "Locality Name";

$lang['inquiry'] = "Inquiry";
$lang['all-inquiry'] = "All Inquiry";
$lang['add-inquiry'] = "Add Inquiry";
$lang['update-inquiry'] = "Update Inquiry";
$lang['inquiry-no'] = "Inquiry Number";
$lang['inquiry-company'] = "Inquiry Company";
$lang['anand'] = "Anand";
$lang['unnati'] = "Unnati";
$lang['bhavesh'] = "Bhavesh";
$lang['krupal'] = "Krupal";
$lang['qyt'] = "QYT";
$lang['rate'] = "Amount";
$lang['description'] =  "Description";
$lang['inquiry-details'] = "Inquiry Details";
$lang['no'] = "No";
$lang["kg"] = "Kg";
$lang['per'] = "Per";
$lang['original-qyt'] = "Original QYT";
$lang['total-amout'] = "Total Amount";
$lang['delete-description'] = "Delete Description";
$lang['delete-description-message'] = "Are You Sure Want To Remove Description ?";
$lang['inquiry-date'] = "Inquiry Date";
$lang['inq-no'] = "Inquiry Number ";
$lang['anand-inquiry-date'] = "Anand Inquiry Date";
$lang['unnati-inquiry-date'] = "Unnati Inquiry Date";
$lang['krupal-inquiry-date'] = "Krupal Inquiry Date";
$lang['bhavesh-inquiry-date'] = "Bhavesh Inquiry Date";
$lang['anand-rate'] = "Anand Rate";
$lang['unnati-rate'] = "Unnati Corporation Rate";
$lang['bhavesh-rate'] = "Bhavesh Rate";
$lang['delete'] = "Delete";
$lang['genrate-inquiry'] = "Genrate Inqiry";
$lang['description'] = "Description";
$lang['add-description'] = "Add Description";
$lang['all-description'] = "All Description";

$lang['edit'] = "Edit";
$lang['search'] = "Search";
$lang['reset'] = "Reset";
$lang['vendor'] = "Vendor";
$lang['add-vendor'] = "Add Vendor";
$lang['vendor-name'] = "Vendor Name";
$lang['vendor-number'] = "Vendor Mobile No";
$lang['vendor-address'] = "Vendor Address";
$lang['vendor-gst-number'] = "Vendor Gst Number";
$lang['vendor-pay-out'] = "Vendor Pay Out";
$lang['vendor-pay-in'] = "Vendor Pay In";
$lang['vendor-person-name'] = "Vendor Person Name";
$lang['vendor-type'] = "Vendor Type";

$lang['name'] = "Name";
$lang['email_or_phone'] =  "Email Or Phone";
$lang['signup'] = "Signup";

$lang['product'] = "Product";
// Add these to your language file (e.g., application/language/english/custom_lang.php)

$lang['vehicle-type'] = 'Vehicle Type';
$lang['brand'] = 'Brand';
$lang['model'] = 'Model';
$lang['year'] = 'Year';
$lang['mileage'] = 'Mileage';
$lang['fuel-type'] = 'Fuel Type';
$lang['transmission'] = 'Transmission';
$lang['seating-capacity'] = 'Seating Capacity';
$lang['rental-price'] = 'Rental Price';
$lang['availability'] = 'Availability';
$lang['description'] = 'Description';
$lang['vehicle-image'] = 'Vehicle Image';
$lang['add-vehicle'] = 'Add Vehicle';
$lang['vehicle_added_successfully'] = 'Vehicle added successfully!';
$lang['failed_to_add_vehicle'] = 'Failed to add vehicle.';
$lang['sr-no'] = "Sr No.";
$lang['add-product'] = 'Add Product';
$lang['products'] = "Products";
$lang['car-rent'] = "Car Rent";


$lang['product_details'] = "Product Details";
$lang['product_name'] = "Product Name";
$lang['office_chair'] = "Office Chair";
$lang['no_description'] = "No description available";
$lang['vehicle_details'] = "Vehicle Details";
$lang['vehicle_type'] = "Vehicle Type";
$lang['brand'] = "Brand";
$lang['model'] = "Model";
$lang['year'] = "Year";
$lang['mileage'] = "Mileage";
$lang['fuel_type'] = "Fuel Type";
$lang['transmission'] = "Transmission";
$lang['seating_capacity'] = "Seating Capacity";
$lang['rental_price'] = "Rental Price";
$lang['availability'] = "Availability";
$lang['recommended_by'] = "Recommended by";
$lang['book'] = "Book";
$lang['customer_details'] = "Customer Details";
$lang['full_name'] = "Full Name";
$lang['enter_name'] = "Enter Full Name";
$lang['phone_number'] = "Phone Number";
$lang['enter_phone'] = "Enter Phone Number";
$lang['email_address'] = "Email Address";
$lang['enter_email'] = "Enter Email Address";
$lang['address'] = "Address";
$lang['optional'] = "Optional";
$lang['enter_address'] = "Enter Your Address";
$lang['rental_duration'] = "Rental Duration (in days)";
$lang['enter_rental_duration'] = "Enter Rental Duration";
$lang['payment_method'] = "Payment Method";
$lang['credit_card'] = "Credit Card";
$lang['paypal'] = "PayPal";
$lang['bank_transfer'] = "Bank Transfer";
$lang['special_requests'] = "Special Requests";
$lang['enter_special_requests'] = "Enter any special requests or notes";
$lang['close'] = "Close";
$lang['submit'] = "Submit";
$lang['book_now'] = "Book Now";
$lang['booked_successfully'] = "Booked successfully!";
$lang['failed_to_book'] = "Failed to book.";
$lang['vehicle_type'] = 'Vehicle Type';
$lang['pickup_date'] = 'Pickup Date';
$lang['dropoff_date'] = 'Dropoff Date';
$lang['drivers_license'] = 'Driver\'s License';


$lang['order'] = "Order";

$lang['orders'] = "Orders";

$lang['all-order'] = "All Order";
$lang['product-name'] = 'Product Name';
$lang['customer-name'] = 'Customer Name';
$lang['customer-phone'] = 'Customer Phone';
$lang['customer-email'] = 'Customer Email';
$lang['duration'] = 'Duration';
$lang['license-no'] = 'License No.';
$lang['order-note'] = 'Order Note';
