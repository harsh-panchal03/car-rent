<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
defined('SHOW_DEBUG_BACKTRACE') or define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
defined('FILE_READ_MODE')  or define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') or define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE')   or define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE')  or define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
defined('FOPEN_READ')                           or define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE')                     or define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE')       or define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE')  or define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE')                   or define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE')              or define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT')            or define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT')       or define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS')        or define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          or define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         or define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   or define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  or define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') or define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     or define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       or define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      or define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      or define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

defined('ADMIN_THEME') or define('ADMIN_THEME', "#fff");

defined('SITE_URL') or define('SITE_URL', 'http://localhost/car-rent/');
defined('DATE_TIME')    or define('DATE_TIME', date("y-m-d"));
defined('ROLE_ADMIN') or define('ROLE_ADMIN', "admin");
defined('ROLE_USER') or define('ROLE_USER', "user");

defined('DEFAULT_DATE_FORMATE') or define('DEFAULT_DATE_FORMATE', "DD-MM-YYYY");

defined('SHOW_CONFIRM_BOX') or define('SHOW_CONFIRM_BOX', TRUE);

defined('LOGIN_URL') or define('LOGIN_URL', SITE_URL . 'login/');
defined('LOGIN_TABLE') or define('LOGIN_TABLE', "login_master");

defined('LOGIN_FOLDER') or define('LOGIN_FOLDER', 'login/');
defined('ADMIN_FOLDER') or define('ADMIN_FOLDER', 'admin/');
defined('ASSET_FOLDER') or define('ASSET_FOLDER', SITE_URL . "assets/");
defined('AJAX_FOLDER') or define('AJAX_FOLDER', ADMIN_FOLDER . "ajax-view/");
defined('JS_FOLDER') or define('JS_FOLDER', ASSET_FOLDER . "js/");
defined('CSS_FOLDER') or define('CSS_FOLDER', ASSET_FOLDER . "css/");
defined('IMAGES_FOLDER') or define('IMAGES_FOLDER', ASSET_FOLDER . "images/");
defined('UPLOAD_FOLDER') or define('UPLOAD_FOLDER', SITE_URL . "uploads/");

defined('FONTAWESOME_FOLDER') or define('FONTAWESOME_FOLDER', ASSET_FOLDER . "fontawesome/");
defined('ACTIVE_STATUS') or define('ACTIVE_STATUS', 1);
defined('INACTIVE_STATUS') or define('INACTIVE_STATUS', 0);

defined('ACTIVE_STATUS_TEXT') or define('ACTIVE_STATUS_TEXT', "Active");
defined('INACTIVE_STATUS_TEXT') or define('INACTIVE_STATUS_TEXT', "Inactive");

defined('SUCCESS_AJAX_CALL') or define('SUCCESS_AJAX_CALL', 1);
defined('ERROR_AJAX_CALL') or define('ERROR_AJAX_CALL', 101);


defined('PER_PAGE') or define('PER_PAGE', 20);
defined('DEFAULT_PAGE_INDEX') or define('DEFAULT_PAGE_INDEX', 1);

defined('DASHBOARD_URL') or define('DASHBOARD_URL', SITE_URL . 'dashboard/');
defined('SUB_STATION_URL') or define('SUB_STATION_URL', SITE_URL . "sub_station/");
defined('SUB_STATION_MASTER_TABLE') or define('SUB_STATION_MASTER_TABLE', 'sub_station_master');

defined('EXECUTIVE_ENGINEER') or define('EXECTIVE_ENGNEER', "executive_engineer");
defined('DEPUTY_ENGINEER') or define('DEPUTY_ENGINEER', "deputy_engineer");
defined('JUNIOR_ENGINEER') or define('JUNIOR_ENGINEER', "junior_engineer");

defined('KV_66_SUB_STATION') or define('KV_66_SUB_STATION', 66);
defined('KV_132_SUB_STATION') or define('KV_132_SUB_STATION', 132);
defined('KV_220_SUB_STATION') or define('KV_220_SUB_STATION', 220);
defined('KV_400_SUB_STATION') or define('KV_400_SUB_STATION', 400);


defined('CITY_TABLE') or define('CITY_TABLE', "city_master");
defined('CITY_URL') or define('CITY_URL', SITE_URL . "city_master/");
defined('LOCALITY_TABLE') or define('LOCALITY_TABLE', "locality_master");
defined('LOCALITY_URL') or define('LOCALITY_URL', SITE_URL . "locality_master/");

defined('GUJARAT_STATE_ID') or define('GUJARAT_STATE_ID', 1);
defined('MAHARASTRA_STATE_ID') or define('MAHARESTRA_STATE_ID', 2);

defined('INQUIRY_MASTER_TABLE') or define('INQUIRY_MASTER_TABLE', "inquiry_master");
defined('INQUIRY_MASTER_URL') or define('INQUIRY_MASTER_URL', SITE_URL . "inquiry_master/");
defined('ANAND') or define('ANAND', "ANAND ELECTRICAL");
defined('UNNATI') or define('UNNATI', "UNNATI CORPORATION");
defined('BHAVESH') or define('BHAVESH', "BHAVESH TEXTITLE");
defined('KRUPAL') or define('KRUPAL', "KRUPAL ENTERPRISE");
defined('NO') or define('NO', 'NO');
defined('KG') or define('KG', 'KG');
defined('SET') or define('SET', 'SET');

defined('INQUIRY_DESCRIPTION_DETAILS_TABLE') or define('INQUIRY_DESCRIPTION_DETAILS_TABLE', "inquiry_description_details");
defined("DESCRIPTION_DETAILS_MASTER_TABLE") or define('DESCRIPTION_DETAILS_MASTER_TABLE', "description_details_master");

defined("DESCRIPTION_DETAILS_MASTER_URL") or define('DESCRIPTION_DETAILS_MASTER_URL', SITE_URL . "description_master/");

defined('VENDOR_MASTER_URL') or define('VENDOR_MASTER_URL', SITE_URL . "vendor_master/");
defined('VENDOR_MASTER_TABLE') or define('VENDOR_MASTER_TABLE', "vendor_master");
defined('GUEST_URL') or define('GUEST_URL', SITE_URL . 'guest/');



defined('PRODUCT_URL') or define('PRODUCT_URL', SITE_URL . "product_master/");
defined('PRODUCT_TABLE') or define('PRODUCT_TABLE', "product_master");


defined('ORDER_URL') or define('ORDER_URL', SITE_URL . "order_master/");
defined('ORDER_TABLE') or define('ORDER_TABLE', "order_master");
