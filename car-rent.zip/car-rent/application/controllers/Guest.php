<?php

class Guest extends CI_Controller
{

    public $tableName;
    public $folderName;
    public $redirectUrl;
    public $perPageRecord;


    public function __construct()
    {
        parent::__construct();
        $this->tableName = "";
        $this->folderName = "";
        $this->redirectUrl = "";
        $this->perPageRecord = PER_PAGE;
        $this->load->model('my_model', 'my_model');
    }

    public function guestObject()
    {
        echo "guest function called";
        die;
    }

    public function createOrder()
    {
        // Set validation rules for the order fields
        // $this->form_validation->set_rules("customerName", "Customer Name", "required|trim");
        // $this->form_validation->set_rules("customerPhone", "Customer Phone", "required|trim|numeric");
        // $this->form_validation->set_rules("customerEmail", "Customer Email", "required|trim|valid_email");
        // $this->form_validation->set_rules("vehicleType", "Vehicle Type", "required|trim");
        // $this->form_validation->set_rules("rentalDuration", "Rental Duration", "required|numeric");
        // $this->form_validation->set_rules("pickupDate", "Pickup Date", "required|trim");
        // $this->form_validation->set_rules("dropoffDate", "Dropoff Date", "required|trim");
        // $this->form_validation->set_rules("driversLicense", "Driver's License", "required|trim");
        // $this->form_validation->set_rules("paymentMethod", "Payment Method", "required|trim");

        // // If validation fails, return error response as JSON
        // if ($this->form_validation->run() != TRUE) {
        //     $errorMessages = validation_errors();
        //     echo json_encode(['status' => 'error', 'message' => $errorMessages]);
        //     return;
        // }



        // Prepare the order data to be inserted into the database
        $orderData = [
            'v_name'              => $this->input->post('customerName'),
            'v_phone'             => $this->input->post('customerPhone'),
            'v_email'             => $this->input->post('customerEmail'),

            'v_rental_duration'   => $this->input->post('rentalDuration'),

            'v_drivers_license'   => $this->input->post('driversLicense'),


            'v_special_request'   => $this->input->post('specialRequests'),
            'i_product_id'        => $this->anand_electrical->decode($this->input->post('record_id')),
        ];

        // Insert order data into the database using your model (assuming the model and table exist)
        $insertId = $this->my_model->insertTableData('order_master', $orderData);

        if ($insertId > 0) {
            // Send success response as JSON
            echo json_encode(['status' => 'success', 'message' => 'Order created successfully']);
        } else {
            // Send failure response if insertion fails
            echo json_encode(['status' => 'error', 'message' => 'Failed to create order']);
        }
    }


    public function home()
    {

        $headerData = $data = [];
        $headerData['name'] = "panchal harsh";

        $data['productDetails'] = $this->my_model->selectData(PRODUCT_TABLE, ['*'], ["t_is_deleted !=" => ACTIVE_STATUS]);


        $this->load->view('home/header', $headerData);
        $this->load->view('home/home', $data);
        $this->load->view('home/footer');
    }

    public function signup()
    {

        // $this->load->view('home/header');
        $this->load->view('home/signup');
        // $this->load->view('home/footer' );


    }

    public function whyUs()
    {

        $this->load->view('home/header');
        $this->load->view('home/why-us');
        $this->load->view('home/footer');
    }

    public function contactUs()
    {

        $this->load->view('home/header');
        $this->load->view('home/contact-us');
        $this->load->view('home/footer');
    }
    public function term()
    {

        $this->load->view('home/header');
        $this->load->view('home/term');
        $this->load->view('home/footer');
    }

    public function productDetail($id)
    {

        $data['productDetails'] = $this->my_model->getSingleRecordById(PRODUCT_TABLE, ['*'], ["i_id" => $id]);
        // echo "<pre>";
        // print_r($data['productDetails']);
        // die;

        $this->load->view('home/header');
        $this->load->view('home/product-detail', $data);
        $this->load->view('home/footer');
    }

    public function checkLogin() {}


    public function logout()
    {
        // Clear all session data
        $this->session->sess_destroy();

        // Optionally set a flash message
        $this->anand_electrical->setFlashMessage("success", "You have been successfully logged out.");

        // Redirect to the login page
        redirect(LOGIN_URL);
    }
    public function commonSessionEntry($checkLogin)
    {

        if (!empty($checkLogin)) {

            $userData = [];
            $userData['userName'] = (!empty($checkLogin->v_name) ? $checkLogin->v_name : "");
            $userData['role'] = (!empty($checkLogin->v_role) ? $checkLogin->v_name : "");
            $userData['userId'] = (!empty($checkLogin->i_id) ? $checkLogin->i_id : "");
            $userData['userEmail'] = (!empty($checkLogin->v_email) ? $checkLogin->v_email : "");

            $this->session->set_userdata($userData);
        }
    }
}
