<?php

class Login extends Guest
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->has_userdata("userId") != false && !empty($this->session->userdata("userId"))) {
            redirect(DASHBOARD_URL);
        }


        $this->load->model("login_model", "crud_model");
    }


    public function index()
    {



        $this->load->view('home/signup');
    }

    public function showAddForm()
    {
        echo "hi0;";
    }



    public function checkAdminLogin()
    {

        if (!empty($this->input->post())) {
            $loginType = $this->input->post('login_type'); // 'login' or 'signup'

            if ($loginType === 'login') {
                // Login process
                //  $this->form_validation->set_rules('login_email', $this->lang->line('email'), 'trim|required|valid_email|xss_clean');
                $this->form_validation->set_rules('login_password', $this->lang->line('password'), 'trim|required|xss_clean');

                if ($this->form_validation->run() !== true) {
                    $this->anand_electrical->setFlashMessage("danger", validation_errors());
                    redirect(LOGIN_URL);
                } else {
                    $email = $this->input->post("login_email");
                    $password = $this->input->post("login_password");

                    $checkLogin = $this->crud_model->getRecordDetails([], ["v_email" => $email]);

                    if (!empty($checkLogin)) {
                        if ($checkLogin->t_is_active != ACTIVE_STATUS) {
                            $this->anand_electrical->setFlashMessage("danger", $this->lang->line("inactive-account"));
                        } elseif (password_verify($password, $checkLogin->v_password)) {
                            $this->commonSessionEntry($checkLogin);
                            redirect(DASHBOARD_URL);
                        } else {
                            $this->anand_electrical->setFlashMessage("danger", $this->lang->line("invalid-password"));
                        }
                    } else {
                        $this->anand_electrical->setFlashMessage("danger", $this->lang->line("email-not-exist"));
                    }
                    redirect(LOGIN_URL);
                }
            } elseif ($loginType === 'signup') {
                // Signup process
                $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
                //   $this->form_validation->set_rules('signup_email', 'Email', 'trim|required|valid_email|xss_clean');
                $this->form_validation->set_rules('signup_password', 'Password', 'trim|required|xss_clean');

                if ($this->form_validation->run() !== true) {
                    die(validation_errors());
                    $this->anand_electrical->setFlashMessage("danger", validation_errors());
                    redirect(LOGIN_URL);
                } else {
                    $name = $this->input->post("name");
                    $email = $this->input->post("signup_email");
                    $signupPassword = password_hash($this->input->post("signup_password"), PASSWORD_DEFAULT);

                    $existingUser = $this->crud_model->getRecordDetails(['i_id'], ["v_email" => $email]);

                    if (!empty($existingUser)) {
                        $this->anand_electrical->setFlashMessage("danger", "Email already registered.");
                    } else {
                        $data = [
                            'v_name' => $name,
                            'e_role' => 'user',
                            'v_email' => $email,
                            'v_password' => $signupPassword,
                            't_is_active' => ACTIVE_STATUS,
                            'dt_created_at' => date('Y-m-d H:i:s'),
                            'i_created_id' => 0, // Default to system or admin
                            'v_ip' => $this->input->ip_address()
                        ];

                        $result = $this->crud_model->insertTableData('login_master', $data);

                        if ($result > 0) {
                            $checkLogin = $this->crud_model->getRecordDetails([], ["v_email" => $email]);
                            $this->commonSessionEntry($checkLogin);
                            redirect(DASHBOARD_URL);
                        } else {
                            $this->anand_electrical->setFlashMessage("danger", "Error creating account. Please try again.");
                        }
                    }
                    redirect(LOGIN_URL);
                }
            } else {
                $this->anand_electrical->setFlashMessage("danger", "Invalid request type.");
                redirect(LOGIN_URL);
            }
        } else {
            redirect(LOGIN_URL);
        }
    }
}
