<?php

class Order_model extends My_model
{

    public function __construct()
    {
        parent::__construct();
        $this->singleRecord = false;
    }

    public function getRecordDetails($selectData = [], $whereData = [], $likeData = [], $additionalData = [])
    {

        $tableName = ORDER_TABLE . " as o";

        if (empty($selectData)) {
            $selectData = [
                'o.i_id',
                'o.v_name',
                'p.v_name as product_name',               // Customer's name
                'o.v_phone',                 // Customer's phone number
                'o.v_email',                 // Customer's email address
                'o.v_rental_duration',       // Duration of the rental
                'o.v_drivers_license',       // Driver's license number
                'o.v_special_request',       // Special requests
                'o.i_product_id',            // Product ID related to the order
                'o.t_is_active',             // Status of the order (active or inactive)
            ];
        }

        if (isset($whereData['singleRecord']) && $whereData['singleRecord'] != false) {
            $this->singleRecord = true;
            unset($whereData['singleRecord']);
        }


        $joinData = [
            [
                'tableName' => PRODUCT_TABLE . " as p",
                'condition' => "p.i_id = o.i_product_id",
                'type' => "left",
            ],

        ];

        $defaultWhere = [];
        $defaultWhere['o.t_is_deleted'] = INACTIVE_STATUS;

        $whereData = array_merge($defaultWhere, $whereData);

        $data = [];

        if ($this->singleRecord != false) {
            $data = $this->getSingleRecordWithJoinById($tableName, $selectData, $joinData, $whereData);
        } else {
            $data = $this->selectJoinData($tableName, $selectData, $joinData, $whereData);
        }

        return $data;
    }
}
