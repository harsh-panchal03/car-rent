<?php 

if(isset($recordDetails) && !empty($recordDetails)) {
    
    $rowIndex = ( $pageNo - 1 )* PER_PAGE;
    
    
    foreach ($recordDetails as $recordDetail){
        
        
        $encodeId = $this->anand_electrical->encode ( $recordDetail->i_id );
        
        $status = $this->lang->line('active');
        
        if(isset($recordDetail->t_is_active) && $recordDetail->t_is_active == INACTIVE_STATUS){
            $status = $this->lang->line('inactive');
        }
        
        ?>
        	<tr>
    <td class="sr-col"><?php echo ++$rowIndex ?></td>
    <td><?php echo (!empty($recordDetail->v_name) ? $recordDetail->v_name : null) ?></td>
    <td class="text-center"><?php echo (!empty($recordDetail->v_vehicle_type) ? $recordDetail->v_vehicle_type : null) ?></td>
    <td><?php echo (!empty($recordDetail->v_brand) ? $recordDetail->v_brand : null) ?></td>
    <td><?php echo (!empty($recordDetail->v_model) ? $recordDetail->v_model : null) ?></td>
    <td><?php echo (!empty($recordDetail->v_year) ? $recordDetail->v_year : null) ?></td>
    <td><?php echo (!empty($recordDetail->v_mileage) ? number_format($recordDetail->v_mileage) . ' km' : null) ?></td>
    <td><?php echo (!empty($recordDetail->v_fuel_type) ? $recordDetail->v_fuel_type : null) ?></td>
    <td><?php echo (!empty($recordDetail->v_transmission) ? $recordDetail->v_transmission : null) ?></td>
    <td class="text-center"><?php echo (!empty($recordDetail->v_seating_capacity) ? $recordDetail->v_seating_capacity : null) ?></td>
    <td class="text-center"><?php echo (!empty($recordDetail->v_rental_price) ? number_format($recordDetail->v_rental_price, 2) : null) ?></td>
    <td class="text-center"><?php echo (!empty($recordDetail->e_availability) ? $recordDetail->e_availability : null) ?></td>
    <td class="actions-col">
        <a title="<?php echo $this->lang->line("edit") ?>" href="<?php echo PRODUCT_URL."showEditForm/".$encodeId ?>" class="btn btn-sm btn-info mb-1">
            <i class="fas fa-fw fa-pencil-alt"></i>
        </a>
        <button title="<?php echo $status ?>" data-record-id="<?php echo $encodeId ?>" onclick="updateStatus(this , 'sub_station')" class="btn btn-sm btn-warning mb-1">
            <i class="fa fa-eye-slash fa-fw iconStatus"></i>
        </button>
        <button title="<?php echo $this->lang->line('delete') ?>" onclick="deleteRecord(this , 'prod')" data-record-id="<?php echo $encodeId ?>" class="btn btn-sm btn-danger mb-1">
            <i class="fa fa-trash fa-fw"></i>
        </button>
    </td>
</tr>

        
        <?php 
        
    }
    
    if(!empty($pagination)){
        ?>
        	<input name="current_page" type="hidden" id="current_page" value="<?php echo $pagination['current_page'] ?>">
            <input name="last_page" type="hidden" id="last_page" value="<?php echo $pagination['last_page'] ?>">
            <input name="per_page" type="hidden" id="per_page" value="<?php echo $pagination['per_page_record'] ?>">
        <?php 
    }
    
}else{
    ?>
    	<tr class="text-center">
    		<td colspan="13"> <?php echo $this->lang->line('no-record-found')?>  </td>
    	</tr>
    <?php 
}

echo $this->load->view( "common-record-count" , [] , true );

?>