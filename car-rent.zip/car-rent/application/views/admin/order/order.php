<div class="breadcrumb-wrapper d-lg-flex p-3 border-bottom">
    <h1 class="h3 mb-lg-0 mr-3" id="pageTitle"><?php echo $this->lang->line("orders") ?>( <span id="total-record-count"></span> )</h1>
    <div class="ml-auto text-right">
        <!-- <a href="<?php // echo PRODUCT_URL . "showAddForm" 
                        ?>" class="btn btn-light text-dark border btn-sm mr-2" title="<?php // echo $this->lang->line('add-product') 
                                                                                        ?>"><i class="fas fa-plus"></i><?php // echo $this->lang->line('add-product') 
                                                                                                                        ?></a> -->
        <button class="btn btn-light border btn-sm" data-toggle="collapse" data-target="#searchFilter" title="Toggle Filter"><i class="fas fa-filter"></i><?php echo $this->lang->line('filter') ?></button>
    </div>
</div>
<div class="container-fluid pt-3">
    <?php echo $this->session->flashdata("myMessage") ?>
    <div class="collapse" id="searchFilter">
        <div class="card card-body border-0 shadow mb-4">
            <div class="row">
                <!-- Name Filter -->

                <!-- Search and Reset Buttons -->
                <div class="col-md pt-lg-2 mt-md-4 mt-lg-0">
                    <button type="button" onclick="filterData()" class="btn btn-info mt-lg-3"><?php echo $this->lang->line('search') ?></button>
                    <button type="button" onclick="resetFilter()" class="btn btn-outline-secondary reset-wild-tigers mt-lg-3"><?php echo $this->lang->line('reset') ?></button>
                </div>
            </div>
        </div>
    </div>

    <div class="filter-result-wrapper">
        <h3 class="h4 mb-3"><?php echo $this->lang->line("all-orders") ?></h3>
        <div class="card card-body shadow-sm">
            <div class="table-responsive">
                <table class="table table-sm table-bordered table-hover">
                    <thead>
                        <tr>
                            <th class="sr-col"><?php echo $this->lang->line("sr-no") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("product-name") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("customer-name") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("customer-phone") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("customer-email") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("duration") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("license-no") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("order-note") ?></th>
                            <th class="actions-col"><?php echo $this->lang->line("actions") ?></th>
                        </tr>
                    </thead>
                    <tbody class="ajax-view">
                        <?php echo $this->load->view(AJAX_FOLDER . "order/order-list", [], true); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script>
    var product_url = "<?php echo PRODUCT_URL ?>";
    var paginationUrl = product_url + "filter";

    function searchFiled() {

        var searchData = {};
        searchData.search_status = $.trim($("[name='search_status']").val());
        searchData.search_brand = $.trim($("[name='search_brand']").val());
        searchData.search_category = $.trim($("[name='search_category']").val());
        searchData.search_name = $.trim($("[name='name']").val());
        searchData.search_vehicle_type = $.trim($("[name='search_vehicle_type']").val());
        searchData.search_model = $.trim($("[name='search_model']").val());
        searchData.search_year = $.trim($("[name='search_year']").val());
        searchData.search_mileage = $.trim($("[name='search_mileage']").val());
        searchData.search_fuel_type = $.trim($("[name='search_fuel_type']").val());
        searchData.search_transmission = $.trim($("[name='search_transmission']").val());
        searchData.search_seating_capacity = $.trim($("[name='search_seating_capacity']").val());
        searchData.search_rental_price = $.trim($("[name='search_rental_price']").val());
        searchData.search_availability = $.trim($("[name='search_availability']").val());

        return searchData;



    }


    function filterData() {


        var searchFieldName = searchFiled();


        searchAjax(product_url + 'filter', searchFieldName);



    }
</script>
<?php echo $this->load->view(ADMIN_FOLDER . "srcoll-based-pagination", [], true) ?>