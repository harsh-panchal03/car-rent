<style>
  @import url('https://fonts.googleapis.com/css?family=Fjalla+One|Montserrat:300,400,700,800|Open+Sans:300');

  body {
    height: 100%;
    margin: 0;
    background: #f4f4f4;
    font-family: "Open Sans", sans-serif;
  }

  main {
    max-width: 720px;
    margin: 5% auto;
  }

  .card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    overflow: hidden;
    transition: transform 200ms, box-shadow 200ms;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  }

  .card__title {
    display: flex;
    align-items: center;
    padding: 20px 40px;
    background: #115dd8;
    color: #fff;
  }

  .card__title .icon {
    flex-shrink: 0;
    background: #0d4bb8;
    border-radius: 50%;
    padding: 10px;
    margin-right: 20px;
  }

  .card__title .icon a {
    color: #fff;
    text-decoration: none;
    font-size: 16px;
  }

  .card__title h3 {
    margin: 0;
    font-size: 22px;
    font-weight: 700;
    text-transform: uppercase;
  }

  .card__body {
    display: flex;
    padding: 30px 40px;
    gap: 20px;
  }

  .half {
    flex: 1 1 50%;
    box-sizing: border-box;
  }

  .featured_text {
    margin-bottom: 20px;
  }

  .featured_text h1 {
    font-family: "Montserrat", sans-serif;
    font-size: 32px;
    margin: 0;
    color: #252525;
  }

  .featured_text p {
    margin: 5px 0;
  }

  .featured_text .sub {
    font-size: 18px;
    color: #686e77;
    font-weight: 400;
  }

  .featured_text .price {
    font-family: "Fjalla One", sans-serif;
    font-size: 24px;
    color: #115dd8;
  }

  .image img {
    display: block;
    max-width: 100%;
    border-radius: 10px;
  }

  .description p {
    margin: 0 0 10px;
    color: #555;
    line-height: 1.6;
  }

  .card__content {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .card__content h1 {
    font-size: 24px;
    color: #252525;
    margin: 0;
  }

  .card__details div {
    margin-bottom: 8px;
    font-size: 14px;
    color: #555;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .card__details div i {
    color: #115dd8;
  }

  .reviews {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .reviews .stars {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    gap: 2px;
  }

  .reviews .stars li i {
    color: #f7c01b;
  }

  .card__footer {
    padding: 20px 40px;
    display: flex;
    align-items: center;
    gap: 20px;
    border-top: 2px solid #f4f4f4;
  }

  .recommend p {
    margin: 0;
    font-size: 12px;
    color: #555;
    text-transform: uppercase;
  }

  .recommend h3 {
    margin: 5px 0 0;
    font-size: 16px;
    color: #115dd8;
  }

  .action button {
    border: 1px solid #115dd8;
    background: #115dd8;
    color: #fff;
    padding: 10px 25px;
    border-radius: 50px;
    font-size: 14px;
    cursor: pointer;
    transition: all 200ms;

  }

  .action button:hover {
    background: #fff;
    color: #115dd8;
    border-color: #115dd8;
  }

  .card__footer .action {
    display: flex;
    justify-content: center;
    /* Centers the button horizontally */
    align-items: center;
    /* Centers the button vertically, if needed */
    width: 100%;
  }
</style>

<div class="card">
  <div class="card__title">
    <div class="icon">
      <a href="#"><i class="fa fa-arrow-left"></i></a>
    </div>
    <h3>Vehicle Details</h3>
  </div>
  <div class="card__body">
    <div class="half">

      <div class="image">
        <img src="<?php echo isset($productDetails->v_image_path) && !empty($productDetails->v_image_path) ? $productDetails->v_image_path : 'default_image.jpg'; ?>" alt="Product Image">
      </div>
    </div>
    <div class="half">
      <div class="featured_text">
        <h1><?php echo isset($productDetails->v_name) && !empty($productDetails->v_name) ? $productDetails->v_name : 'Product Name'; ?></h1>
        <p class="sub"> <?php echo isset($productDetails->v_vehicle_type) && !empty($productDetails->v_vehicle_type) ? ucfirst($productDetails->v_vehicle_type) : 'Car'; ?></p> <!-- You can replace this with the relevant description if needed -->
        <p class="price">₹<?php echo isset($productDetails->v_rental_price) && !empty($productDetails->v_rental_price) ? number_format($productDetails->v_rental_price, 2) : '0.00'; ?></p>
      </div>
      <div class="description">
        <p><?php echo isset($productDetails->v_description) && !empty($productDetails->v_description) ? $productDetails->v_description : 'No description available.'; ?></p>
      </div>
      <div class="card__content">
        <h1>Vehicle Details</h1>
        <div class="card__details">
          <div><i class="fa fa-car"></i> Vehicle Type: <?php echo isset($productDetails->v_vehicle_type) && !empty($productDetails->v_vehicle_type) ? ucfirst($productDetails->v_vehicle_type) : 'N/A'; ?></div>
          <div><i class="fa fa-industry"></i> Brand: <?php echo isset($productDetails->v_brand) && !empty($productDetails->v_brand) ? $productDetails->v_brand : 'N/A'; ?></div>
          <div><i class="fa fa-cogs"></i> Model: <?php echo isset($productDetails->v_model) && !empty($productDetails->v_model) ? $productDetails->v_model : 'N/A'; ?></div>
          <div><i class="fa fa-calendar"></i> Year: <?php echo isset($productDetails->v_year) && !empty($productDetails->v_year) ? $productDetails->v_year : 'N/A'; ?></div>
          <div><i class="fa fa-tachometer"></i> Mileage: <?php echo isset($productDetails->v_mileage) && !empty($productDetails->v_mileage) ? number_format($productDetails->v_mileage) : 'N/A'; ?> KM</div>
          <div><i class="fa fa-gas-pump"></i> Fuel Type: <?php echo isset($productDetails->v_fuel_type) && !empty($productDetails->v_fuel_type) ? ucfirst($productDetails->v_fuel_type) : 'N/A'; ?></div>
          <div><i class="fa fa-exchange-alt"></i> Transmission: <?php echo isset($productDetails->v_transmission) && !empty($productDetails->v_transmission) ? ucfirst($productDetails->v_transmission) : 'N/A'; ?></div>
          <div><i class="fa fa-users"></i> Seating Capacity: <?php echo isset($productDetails->v_seating_capacity) && !empty($productDetails->v_seating_capacity) ? $productDetails->v_seating_capacity : 'N/A'; ?></div>
          <div><i class="fa fa-dollar-sign"></i> Rental Price: $<?php echo isset($productDetails->v_rental_price) && !empty($productDetails->v_rental_price) ? number_format($productDetails->v_rental_price, 2) : '0.00'; ?>/day</div>
          <div><i class="fa fa-check"></i> Availability: <?php echo isset($productDetails->e_availability) && !empty($productDetails->e_availability) ? ucfirst($productDetails->e_availability) : 'N/A'; ?></div>
        </div>
      </div>
      <div class="reviews">
        <ul class="stars">
          <li><i class="fa fa-star"></i></li>
          <li><i class="fa fa-star"></i></li>
          <li><i class="fa fa-star"></i></li>
          <li><i class="fa fa-star"></i></li>
          <li><i class="fa fa-star-o"></i></li>
        </ul>
        <span>(64 reviews)</span> <!-- You can dynamically replace this with actual reviews count -->
      </div>
    </div>
  </div>
  <div class="card__footer">
    <div class="action" style="display: center;">
      <button type="button" class="btn btn-primary" onclick="openBoostrapModal('bookingModal')">Book</button>
    </div>
  </div>
</div>

<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="bookingModal" tabindex="-1" role="dialog" aria-labelledby="bookingModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bookingModalLabel"><?php echo $this->lang->line('customer_details'); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="booking-form" method="post">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" for="customerName"><?php echo $this->lang->line('full_name'); ?> <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="customerName" name="customerName" placeholder="<?php echo $this->lang->line('enter_name'); ?>" required autofocus>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" for="customerPhone"><?php echo $this->lang->line('phone_number'); ?> <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="customerPhone" name="customerPhone" placeholder="<?php echo $this->lang->line('enter_phone'); ?>" required>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" for="customerEmail"><?php echo $this->lang->line('email_address'); ?> </label>
                <input type="email" class="form-control" id="customerEmail" name="email" placeholder="<?php echo $this->lang->line('enter_email'); ?>">
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" for="rentalDuration"><?php echo $this->lang->line('rental_duration'); ?> <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="rentalDuration" name="rental_duration" placeholder="<?php echo $this->lang->line('enter_rental_duration'); ?>" required>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label" for="driversLicense"><?php echo $this->lang->line('drivers_license'); ?> <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="driversLicense" name="driversLicense" placeholder="<?php echo $this->lang->line('enter_drivers_license'); ?>" required>
              </div>
            </div>

            <div class="col-md-12">
              <div class="form-group">
                <label class="control-label" for="specialRequests"><?php echo $this->lang->line('special_requests'); ?> <span class="text-muted"><?php echo $this->lang->line('optional'); ?></span></label>
                <textarea class="form-control" id="specialRequests" name="specialRequests" rows="3" placeholder="<?php echo $this->lang->line('enter_special_requests'); ?>"></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <button type="button" onclick="submitOrderForm()" id="submit-btn" class="btn bg-success text-white btn-wide"><?php echo $this->lang->line('submit'); ?></button>
              <button type="button" class="btn btn-outline-secondary btn-wide" data-dismiss="modal"><?php echo $this->lang->line('cancel'); ?></button>
            </div>

          </div>
          <input type="hidden" name="record_id" value="<?php echo (isset($productDetails) && !empty($productDetails->i_id)) ? $this->anand_electrical->encode($productDetails->i_id) : null; ?>">
        </form>
      </div>
    </div>
  </div>
</div>


<script>
  function submitOrderForm() {

    var form = $('#booking-form');

    if (!form.length) {
      console.error("Form element not found!");
      return;
    }

    $.ajax({
      type: "POST",
      url: site_url + "guest/createOrder", // Make sure this URL is correct
      data: form.serialize(), //

      success: function(response) {
        var response = JSON.parse(response);
        console.log("Success:", response); // Log the response for debugging
        // Optionally handle the response (e.g., show a success message or redirect)
        if (response.status == 'success') {
          // alert('Order successfully created!');
          alertify.notify("Order successfully created!", "blue", 5);
          // Optionally close the modal
          $('#bookingModal').modal('hide');
        } else {
          alert('There was an issue with your order. Please try again.');
        }
      },
      error: function(xhr, status, error) {
        // hideLoader(); // Hide the loader in case of error
        console.log("Error:", error); // Log the error for debugging
        alert('An error occurred. Please try again later.');
      }
    });
  }
</script>