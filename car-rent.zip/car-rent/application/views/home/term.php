<style>
    body {

        background-color: #f4f7fb;
        margin: 0;
        padding: 0;
    }

    .terms-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin-top: 40px;
        padding: 20px;
    }

    .terms-card {
        background-color: #ffffff;
        box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 10px;
        border-radius: 8px;
        width: 300px;
        margin: 20px;
        padding: 20px;
        transition: transform 0.3s ease;
        border: 2px solid #00B2EB;
        /* Blue border */
    }

    .terms-card:hover {
        transform: translateY(-5px);
    }

    .terms-card h3 {
        color: #00B2EB;
        /* Blue color for headings */
        font-size: 22px;
        margin-bottom: 10px;
    }

    .terms-card p {
        font-size: 14px;
        color: #333;
        line-height: 1.6;
    }

    .terms-heading {
        text-align: center;
        font-size: 36px;
        font-weight: 900;
        color: #00B2EB;
        margin-bottom: 40px;
    }

    .responsive-container-block.bigContainer {
        background-color: #f4f7fb;
        padding-top: 40px;
        padding-bottom: 40px;
    }

    .terms-heading {
        text-align: center;
        font-size: 36px;
        font-weight: 900;
        color: #00B2EB;
        margin-bottom: 40px;
        padding: 90px;
        /* Added padding */
    }
</style>

<div class="responsive-container-block bigContainer">
    <div class="responsive-container-block Container">
        <p class="terms-heading">Terms and Conditions</p>
        <div class="terms-container">
            <div class="terms-card">
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing and using Rent & Ride, you agree to be bound by the terms and conditions of this agreement. If you do not agree to these terms, you must refrain from using the website.</p>
            </div>

            <div class="terms-card">
                <h3>2. Rental Agreement</h3>
                <p>Rent & Ride provides vehicles for short-term rentals. All rental vehicles must be used for lawful purposes, and the renter agrees to return the vehicle in the same condition as received.</p>
            </div>

            <div class="terms-card">
                <h3>3. Payment and Fees</h3>
                <p>Payment for car rentals must be made in full at the time of booking. Additional fees may apply for extended rentals or damage to the vehicle during the rental period.</p>
            </div>

            <div class="terms-card">
                <h3>4. Insurance Coverage</h3>
                <p>All rentals come with basic insurance coverage. However, additional insurance options are available for purchase to provide extended coverage during your rental period.</p>
            </div>

            <div class="terms-card">
                <h3>5. Vehicle Condition</h3>
                <p>The renter agrees to inspect the vehicle upon receipt and notify Rent & Ride of any pre-existing damage. Rent & Ride is not liable for damage to the vehicle once it is in the renter's possession.</p>
            </div>

            <div class="terms-card">
                <h3>6. Liability</h3>
                <p>Rent & Ride is not responsible for any personal injury, loss, or damage that occurs while using the rented vehicle. The renter assumes all risks and responsibilities during the rental period.</p>
            </div>
        </div>
    </div>
</div>