<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content />
    <meta name="author" content="ANA" />
    <meta name="theme-color" content="<?php echo ADMIN_THEME ?>">
    <title><?php echo $this->lang->line('car-rent') ?> - <?php echo $this->lang->line('login') ?></title>

    <!-- <link rel="stylesheet" href="<?php echo CSS_FOLDER . "font-1.css" ?>"> -->
    <link rel="stylesheet" href="<?php echo CSS_FOLDER . "all.min.css" ?>">
    <!-- css -->
    <link rel="stylesheet" href="<?php echo CSS_FOLDER . "bootstrap.min.css" ?>">
    <link rel="stylesheet" href="<?php echo CSS_FOLDER . "alertify.min.css" ?>">
    <link rel="stylesheet" href="<?php echo CSS_FOLDER . "main.css" ?>">
    <style>
        :root {
            --primary-blue: #0d47a1;
            --secondary-blue: #1976d2;
            --light-blue: #bbdefb;
            --white: #ffffff;
            --light-gray: #f5f5f5;
            --text-dark: #333333;
            --light-blue: #bbdefb;
            /* Light shade of blue */
        }

        .bg-grad-sharp {
            background: var(--white);
        }

        .invalid-feedback {
            font-size: 90%;
        }

        @media (min-width: 992px) {
            .bg-grad-sharp {
                background: linear-gradient(to right, var(--white) 71%, var(--primary-blue) 71%);
            }
        }

        .radio-boxes .radio-box {
            position: relative;
        }

        .radio-boxes .radio-box:not(:last-child) {
            padding-right: 3px;
        }

        .radio-boxes .radio-box input[type="radio"] {
            opacity: 0;
            position: absolute;
            top: 0;
            left: 0;
        }

        .radio-boxes .radio-box .form-check {
            padding-left: 0;
        }

        .radio-boxes .radio-box .form-check-label {
            display: block;
            background: var(--white);
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            border: 1px solid var(--light-gray);
            text-align: center;
            font-weight: bold;
            transition: 0.25s all;
        }

        @media (max-width: 575px) {
            .radio-boxes .radio-box .form-check-label {
                font-size: 80%;
            }
        }

        .radio-boxes .radio-box input[type="radio"]:focus~.form-check-label,
        .radio-boxes .radio-box .form-check-label:hover {
            border-color: var(--secondary-blue);
            color: var(--secondary-blue);
        }

        .radio-boxes .radio-box input[type="radio"]:checked~.form-check-label {
            border-color: var(--primary-blue);
            background-color: var(--primary-blue);
            color: var(--white) !important;
        }

        .light-blue-button {
            background-color: var(--light-blue);
            color: var(--text-dark);
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            /* Smooth transition */
        }

        .light-blue-button:hover {
            background-color: var(--hover-blue);
            transform: scale(1.05);
            /* Slightly enlarge button on hover */
        }

        .light-blue-button:focus {
            outline: none;
            /* Remove default outline */
        }
    </style>

    <link rel="icon" href="<?php echo IMAGES_FOLDER . "signup-bg.webp" ?>">

    <script type="text/javascript" src="<?php echo JS_FOLDER . "jquery-3.3.1.min.js" ?>"></script>

    <script type="text/javascript" src="<?php echo JS_FOLDER . "jquery.validate.js" ?>"></script>
    <script type="text/javascript" src="<?php echo JS_FOLDER . "bootstrap.bundle.min.js" ?>"></script>
    <script type="text/javascript" src="<?php echo JS_FOLDER . "validator-additional-methods.js" ?>"></script>
    <script type="text/javascript" src="<?php echo JS_FOLDER . "common.js" ?>"></script>
    <script type="text/javascript" src="<?php echo JS_FOLDER . "alertify.min.js" ?>"></script>
</head>

<body class="akula-theme-v2 ferrari pt-lg-5 bg-grad-sharp">

    <div class="container pt-5">
        <div class="row">
            <div class="col-lg-6 d-flex align-items-center">
                <img src="<?php echo ASSET_FOLDER . "images/signup-bg.webp" ?>" alt="Site Logo" class="brand-logo-img img-fluid w-75 mb-3 mb-lg-5 mx-auto">
            </div>
            <div class="col-lg-6">
                <?php echo $this->session->flashdata("myMessage") ?>
                <?php echo form_open(LOGIN_URL . "checkAdminLogin", ["id" => "login-form", "method" => "post"]) ?>
                <div class="card card-login pb-3 mx-auto my-5 border-0 shadow-lg bg-transparents">
                    <div class="card-body pt-5">
                        <h3 class="font-weight-lighter mb-lg-3 login-account"><span><?php echo $this->lang->line('login-account') ?></span></h3>
                        <div class="radio-boxes row p-1 bg-white rounded mb-3">
                            <div class="radio-box col-md-6 col-6 mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="login_type" id="login" value="login" checked>
                                    <label class="form-check-label custom-type-label" for="login">Login</label>
                                </div>
                            </div>
                            <div class="radio-box col-md-6 col-6 mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="login_type" id="signup" value="signup">
                                    <label class="form-check-label custom-type-label" for="signup">
                                        signup
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div id="login-fields">
                            <div class="form-group">
                                <label for="login_email" class="email-label"><?php echo $this->lang->line("email") ?>:</label>
                                <input class="form-control" id="login_email" name="login_email" type="text" placeholder="<?php echo $this->lang->line("email") ?>" autofocus />
                            </div>
                            <div class="form-group mb-5">
                                <label for="password"><?php echo $this->lang->line("password") ?>:</label>
                                <input class="form-control" id="login_password" name="login_password" type="password" placeholder="<?php echo $this->lang->line("password") ?>" autocomplete="new-password" />
                            </div>

                            <div class="login-buttons">
                                <button type="submit" class="btn bg-theme login-button btn-block text-white font-weight-bold"><?php echo $this->lang->line("login") ?></button>
                            </div>
                        </div>
                        <div id="signup-fields" style="display:none;">
                            <div class="form-group">
                                <label for="name" class="name-label"><?php echo $this->lang->line("name") ?>:</label>
                                <input class="form-control" id="name" name="name" type="text" placeholder="<?php echo $this->lang->line("name") ?>" autofocus />
                            </div>
                            <div class="form-group">
                                <label for="login_email" class="email-label"><?php echo $this->lang->line("email") ?>:</label>
                                <input class="form-control" id="login_email" name="signup_email" type="text" placeholder="<?php echo $this->lang->line("email_or_phone") ?>" autofocus />
                            </div>
                            <div class="form-group mb-5">
                                <label for="password"><?php echo $this->lang->line("password") ?>:</label>
                                <input class="form-control" id="login_password" name="signup_password" type="password" placeholder="<?php echo $this->lang->line("password") ?>" autocomplete="new-password" />
                            </div>

                            <div class="login-buttons">
                                <button type="submit" class="btn bg-theme login-button btn-block text-white font-weight-bold"><?php echo $this->lang->line("signup") ?></button>
                            </div>
                        </div>

                    </div>
                </div>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
    <script>
        $('[name="login_type"]').on('click', function() {
            if ($(this).val() == 'signup') {
                $('#login-fields').hide();
                $('#signup-fields').show();
            } else {
                $('#signup-fields').hide();
                $('#login-fields').show();
            }
        });

        $("#login-form").validate({
            errorClass: "invalid-input",
            rules: {
                login_email: {
                    required: true
                },
                login_password: {
                    required: true
                },
            },
            messages: {
                login_email: {
                    required: "<?php echo sprintf($this->lang->line("required-text-input"), $this->lang->line("email")); ?>",
                },
                login_password: {
                    required: "<?php echo sprintf($this->lang->line("required-text-input"), $this->lang->line("password")); ?>",
                },
            },
            submitHandler: function(form) {
                showLoader()
                form.submit();
            }
        });
    </script>
</body>

</html>