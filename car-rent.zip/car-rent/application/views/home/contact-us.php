<style>
    .main-div {
        font-family: 'Nunito', sans-serif;
        background-color: #e9f0f7;
        margin: 0;
        padding: 30px;
    }

    .contact-us-page {
        padding: 60px 20px;
    }

    .contact-container {
        background-color: white;
        max-width: 700px;
        margin: 0 auto;
        padding: 30px;
        box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }

    .contact-heading {
        text-align: center;
        font-size: 36px;
        font-weight: 900;
        color: #003366;
        /* Dark Blue */
        margin-bottom: 20px;
    }

    .contact-subheading {
        text-align: center;
        font-size: 16px;
        color: #555;
        margin-bottom: 30px;
    }

    .description {
        font-size: 16px;
        color: #555;
        margin-bottom: 40px;
        text-align: center;
    }

    .form-control {
        border-radius: 8px;
        border: 1px solid #003366;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }

    .submit-btn {
        background-color: #003366;
        /* Dark Blue */
        color: white;
        font-size: 16px;
        font-weight: 600;
        border-radius: 30px;
        width: 100%;
        padding: 12px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        border: none;
    }

    .submit-btn:hover {
        background-color: #002147;
    }

    .form-group label {
        font-weight: 600;
        color: #003366;
    }

    .form-group input,
    .form-group textarea {
        margin-bottom: 20px;
    }

    .contact-info {
        font-size: 18px;
        text-align: center;
        color: #003366;
        margin-top: 30px;
    }

    .contact-info a {
        color: #003366;
        text-decoration: none;
    }

    .contact-info a:hover {
        text-decoration: underline;
    }
</style>

<div class="main-div">

    <div class=" contact-us-page">
        <div class="contact-container">
            <h1 class="contact-heading">Contact Us</h1>
            <p class="contact-subheading">
                We’re here to assist you! Fill out the form below, and our team will get back to you as soon as possible.
            </p>

            <p class="description">
                Whether you have a question about our services, need assistance with booking, or would like to provide feedback, we're here to help. Fill in the details below and we'll get back to you shortly.
            </p>

            <!-- Contact Form -->
            <form action="/submit-form" method="POST">
                <div class="row">
                    <!-- Name Field -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Your Name <span class="text-danger">*</span>:</label>
                            <input type="text" class="form-control" id="name" name="name" required placeholder="Enter your full name">
                        </div>
                    </div>

                    <!-- Email Field -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Your Email <span class="text-danger">*</span>:</label>
                            <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your email address">
                        </div>
                    </div>

                    <!-- Message Field -->
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="message">Your Message <span class="text-danger">*</span>:</label>
                            <textarea class="form-control" id="message" name="message" rows="4" required placeholder="Write your message here"></textarea>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="col-md-12 mt-4">
                        <button type="submit" class="submit-btn">Submit</button>
                    </div>

                    <!-- Cancel Button -->
                    <div class="col-md-12 mt-2">
                        <a href="#" class="btn btn-outline-secondary w-100 mt-2">Cancel</a>
                    </div>
                </div>
            </form>

            <!-- Contact Information -->
            <div class="contact-info">
                <p>If you prefer, you can reach us directly:</p>
                <p>Email: <a href="mailto:support@rentandride.com">support@rentandride.com</a></p>
                <p>Phone: <a href="tel:+1234567890">+1 234 567 890</a></p>
            </div>
        </div>
    </div>
</div>